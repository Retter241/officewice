

     
       {{--  
<img src="{{URL::asset('img/bg_ow.jpg')}}">
        <img src="{{asset('storage/images/bg_ow.jpg')}}">
        {{ Html::image('img/bg_ow.jpg') }}


        --}} 
{{dd($resp)}}



