<?php 


echo $_SERVER['REMOTE_ADDR'];
echo '<br/>';
echo $_SERVER['SERVER_ADDR'];

//phpinfo();


?>