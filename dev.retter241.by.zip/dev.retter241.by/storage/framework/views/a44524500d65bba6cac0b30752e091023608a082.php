<?php
/**
 * Created by PhpStorm.
 * User: Retter-241
 * Date: 10.09.2018
 * Time: 14:05
 */

?>
<?  echo $response_message;  ?>

<pre>
 
</pre>
