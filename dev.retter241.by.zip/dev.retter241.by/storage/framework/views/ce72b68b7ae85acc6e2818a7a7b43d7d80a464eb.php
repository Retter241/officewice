<h1><?php echo e($action_type); ?></h1>
<h2><?php echo e(Auth::user()->login); ?></h2>





<a href="<?php echo e(route('logout')); ?>"> Выйти </a>