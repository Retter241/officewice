<?php $__env->startSection('content'); ?>
<div class="container body">

        <div class="row">

            <div class="col-md-7">

                <nav aria-label="breadcrumb">

                  <ol class="breadcrumb">

                    <li class="breadcrumb-item"><a href="index.html">Грузы по странам</a></li>

                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($breadcrumbs); ?></li>

                  </ol>

                </nav>          

            </div>

            <div class="col-md-5">

                <p class="text-right update-time">Последнее обновление системы:<br>28.09.2018 в 14:30 (GTM +03:00)</p>

            </div>

            <div class="col-12">                

                <h1>Актуальные грузы c погрузкой и выгрузкой в стране <?php echo e($breadcrumbs); ?></h1>

                <p>Вы можете оформить заявку и забрать груз онлайн или перезвонить по телефонам вверху этой страницы</p> 

            </div>

            <div class="col-12" id="export">

                <h2>Грузы c погрузкой в стране <?php echo e($breadcrumbs); ?> (экспорт):</h2>

                <a class="navi-page" href="#import">Смотреть грузы c выгрузкой в стране <?php echo e($breadcrumbs); ?> (импорт)</a>

                <div class="row no-gutters countries-grid">

                    <div class="col-12 cargo-head-wrap d-none d-sm-none d-md-block">

                        <div class="row">

                            <div class="col-md-1 cargo-id text-center">

                                <p>Номер</p>

                            </div>

                            <div class="col-md-2 cargo-route text-center">

                                <p>Маршрут</p>

                            </div>

                            <div class="col-md-1 cargo-date text-center">

                                <p>Дата погрузки</p>

                            </div>

                            <div class="col-md-2 cargo-transport text-center">

                                <p>Требования к транспорту</p>

                            </div>

                            <div class="col-md-2 cargo-load text-center">

                                <p>Груз</p>

                            </div>

                            <div class="col-md-2 cargo-loading text-center">

                                <p>Способ погрузки</p>

                            </div>

                            <div class="col-md-2 cargo-btn text-center">

                            </div>

                        </div>

                    </div>

                  
<?php $__currentLoopData = $deals_to; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-12 cargo-wrap">
                        <div class="row">

                            <div class="col-md-1 cargo-id">

                                <p><?php echo e($deal->id_bitrix); ?></p>

                            </div>

                            <div class="col-md-2 cargo-route">

                                <p><?php echo e($deal->deal_title); ?></p>

                            </div>

                            <div class="col-md-1 cargo-date">

                                <p><?php echo e($deal->deal_delivery_date); ?></p> 

                            </div>

                            <div class="col-md-2 cargo-transport">

                                <p><?php echo e($deal->deal_transport_type); ?></p>

                            </div>

                            <div class="col-md-2 cargo-load">

                                <p><?php echo e($deal->deal_cargo_params); ?></p>

                            </div>

                            <div class="col-md-2 cargo-loading">

                                <p><?php echo e($deal->deal_special_conditions); ?></p>

                            </div>

                            <div class="col-md-2 cargo-btn">

                                <a href="<?php echo e(url('deal/'.$deal->id )); ?>"><button type="button" class="btn btn-primary btn-sm">Инфо</button></a>

                                <a href="<?php echo e(url('deal/'.$deal->id )); ?>"><button type="button" class="btn btn-success btn-sm">Забрать</button></a>

                            </div>

                        </div> 
                    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   

                    
                  

                   

                </div>

            </div>

            <div class="col-md-12" id="import">

                <h2>Грузы c выгрузкой в стране <?php echo e($breadcrumbs); ?> (импорт):</h2>

                <a class="navi-page" href="#export">Смотреть грузы c погрузкой в стране <?php echo e($breadcrumbs); ?> (экспорт)</a>

                <div class="row no-gutters countries-grid">

                    <div class="col-12 cargo-head-wrap d-none d-sm-none d-md-block">

                        <div class="row">

                            <div class="col-md-1 cargo-id text-center">

                                <p>Номер</p>

                            </div>

                            <div class="col-md-2 cargo-route text-center">

                                <p>Маршрут</p>

                            </div>

                            <div class="col-md-1 cargo-date text-center">

                                <p>Дата погрузки</p>

                            </div>

                            <div class="col-md-2 cargo-transport text-center">

                                <p>Требования к транспорту</p>

                            </div>

                            <div class="col-md-2 cargo-load text-center">

                                <p>Груз</p>

                            </div>

                            <div class="col-md-2 cargo-loading text-center">

                                <p>Способ погрузки</p>

                            </div>

                            <div class="col-md-2 cargo-btn text-center">

                            </div>

                        </div>

                    </div><!-- table header -->

    <?php $__currentLoopData = $deals_from; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 cargo-wrap">
                        <div class="row">

                            <div class="col-md-1 cargo-id">

                                <p><?php echo e($deal->id_bitrix); ?></p>

                            </div>

                            <div class="col-md-2 cargo-route">

                                <p><?php echo e($deal->deal_title); ?></p>

                            </div>

                            <div class="col-md-1 cargo-date">

                                <p><?php echo e($deal->deal_delivery_date); ?></p> 

                            </div>

                            <div class="col-md-2 cargo-transport">

                                <p><?php echo e($deal->deal_transport_type); ?></p>

                            </div>

                            <div class="col-md-2 cargo-load">

                                <p><?php echo e($deal->deal_cargo_params); ?></p>

                            </div>

                            <div class="col-md-2 cargo-loading">

                                <p><?php echo e($deal->deal_special_conditions); ?></p>

                            </div>

                            <div class="col-md-2 cargo-btn">

                                <a href="<?php echo e(url('deal/'.$deal->id )); ?>"><button type="button" class="btn btn-primary btn-sm">Инфо</button></a>

                                <a href="<?php echo e(url('deal/'.$deal->id )); ?>"><button type="button" class="btn btn-success btn-sm">Забрать</button></a>

                            </div>

                        </div> 
                    </div><!-- col -->

                   
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>

            </div>

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>