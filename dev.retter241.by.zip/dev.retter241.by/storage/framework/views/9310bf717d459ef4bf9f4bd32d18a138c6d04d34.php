<?php $__env->startSection('content'); ?>
<table>
    <tr>
        <td>ID</td>
        <td>Short Name</td>
        <td>Full Name</td>
        <td>Flag</td>
        <td>Link</td>
        <td>Seo Url</td>
    </tr>


    <?php $__currentLoopData = $all_countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($country->id); ?></td>
            <td><?php echo e($country->short_name); ?></td>
            <td><?php echo e($country->full_name); ?></td>
            <td><?php echo e($country->flag); ?></td> 
            <td><img src="<?php echo e($country->flag); ?>"  style="width:50px;height:20px;"></td>
            <td><?php echo e($country->link); ?></td>
            <td><a href="<?php echo e(url('countries/'.$country->seo_url)); ?>"><?php echo e(url('countries/'.$country->seo_url)); ?></a></td>
</tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>



<?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <strong><?php echo e($t->id); ?> </strong>
      <strong><?php echo e($t->deal_title); ?></strong>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>