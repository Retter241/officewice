<?php
/**
 * Created by PhpStorm.
 * User: Retter-241
 * Date: 10.09.2018
 * Time: 14:05
 */

?>
<?  echo $db_status;  ?><br/>
<?  echo $time;  ?><br/>
<?  echo $response_message;  ?><br/>



<pre>
 
</pre>
